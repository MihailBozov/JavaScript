window.addEventListener("load", solve);

function solve() {
    let expenseTypeInput = document.getElementById('expense');
    let amountInput = document.getElementById('amount');
    let dateInput = document.getElementById('date');

    let previewList = document.getElementById('preview-list');
    let expensesList = document.getElementById('expenses-list');

    let expensesContainer = document.getElementById('expenses');

    let addButton = document.getElementById('add-btn');
    let deleteButton = expensesContainer.querySelector('button');

    addButton.addEventListener('click', addButtonClicked);
    deleteButton.addEventListener('click', deleteButtonClicked);

    function addButtonClicked() {
        previewList.innerHTML = '';

        if (!expenseTypeInput.value.length || !amountInput.value.length || !dateInput.value.length) {
            return;
        }

        let item = document.createElement('li');
        item.className = 'expense-item';

        let article = document.createElement('article');

        let foodType = document.createElement('p');
        foodType.textContent = `Type: ${expenseTypeInput.value}`;

        let foodAmount = document.createElement('p');
        foodAmount.textContent = `Amount: ${amountInput.value}$`;

        let foodDate = document.createElement('p');
        foodDate.textContent = `Date: ${dateInput.value}`;

        article.appendChild(foodType);
        article.appendChild(foodAmount);
        article.appendChild(foodDate);

        let buttonContainer = document.createElement('div');
        buttonContainer.className = 'buttons';

        let editButton = document.createElement('button');
        editButton.classList.add('btn');
        editButton.classList.add('edit');
        editButton.innerText = 'EDIT';

        let okButton = document.createElement('button');
        okButton.classList.add('btn');
        okButton.classList.add('ok');
        okButton.innerText = 'OK';

        buttonContainer.appendChild(editButton);
        buttonContainer.appendChild(okButton);

        item.appendChild(article);
        item.appendChild(buttonContainer);

        previewList.appendChild(item);

        expenseTypeInput.value = '';
        amountInput.value = '';
        dateInput.value = '';

        addButton.disabled = true;

        editButton.addEventListener('click', editButtonClicked);
        okButton.addEventListener('click', okButtonClicked);

        function editButtonClicked() {
            expenseTypeInput.value = foodType.textContent.replace('Type: ', '');
            amountInput.value = foodAmount.textContent.replace('Amount: ', '').replace('$', '');
            dateInput.value = foodDate.textContent.replace('Date: ', '');
            previewList.innerHTML = '';
            addButton.disabled = false;
        }
        function okButtonClicked() {
            let previewItem = previewList.querySelector('li[class="expense-item"]');
            previewItem.querySelector('div[class="buttons"]').remove();
            expensesList.appendChild(previewItem);
            previewList.innerHTML = '';
            addButton.disabled = false;
        }
    }
    function deleteButtonClicked() {
        location.reload();
    }
}